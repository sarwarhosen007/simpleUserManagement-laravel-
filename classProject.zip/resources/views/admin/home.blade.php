 @extends('layouts.admin.master')

 @section('main-content')

   <h3>Admin Home</h3>
	<p>Welcome <strong>{{ Session()->get('userFullName') }}
	               
	</strong></p>
	<p>Your last login was on {{ Session()->get('userLastLogin') }}
	                PM</p>

 @endsection