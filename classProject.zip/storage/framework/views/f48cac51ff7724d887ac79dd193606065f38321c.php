<!DOCTYPE html>
<html>
<head>
	<title>User Manager</title>
</head>
<body>
	<table border="0" width="100%">
		<tr>
			<td width="100"></td>
			<td align="center">
				<h1>User Manager</h1>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td align="center">
				<hr/>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td align="center">
				<a href="<?php echo e(route('loginView')); ?>">Login</a> |
				<a href="<?php echo e(route('registerView')); ?>">Register</a>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td>
				<br/>
				<br/>
				<center>
					
					<br/>
					<br/>
				
				</center>
			</td>
			<td width="100"></td>
		</tr>
	</table>
</body>
</html>