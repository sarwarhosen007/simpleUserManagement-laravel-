<!DOCTYPE html>
<html>
<head>
	<title>Edit - User Manager</title>
</head>
<body>
	<table border="0" width="100%">
		<tr>
			<td width="100"></td>
			<td align="center">
				<h1>User Manager</h1>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td align="center">
				<hr/>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td align="center">
				<a href="<?php echo e(route('userHome')); ?>">Home</a> | 
				<a href="<?php echo e(route('user.show',$userProfile->userId)); ?>">Profile</a> | 
				<a href="<?php echo e(route('settings.edit',$userProfile->userId)); ?>">Settings</a> | 
				<a href="<?php echo e(route('logout')); ?>">Logout</a>
			</td>
			<td width="100"></td>
		</tr>
		<tr>
			<td width="100"></td>
			<td>
				<br/>
				<center>
				<h3>Edit User Information</h3>
				<form method="post" action="<?php echo e(route('user.update',$userProfile->userId)); ?>">
					<?php echo e(csrf_field()); ?>

					 <input type="hidden" name="_method" value="PUT">
						<table>
							<tr>
								<td>FULL NAME: </td>
								<td><input type="text" name="fullname" value="<?php echo e($userProfile->fullname); ?>"></td>
							</tr>
							<tr>
								<td>EMAIL: </td>
								<td><input type="text" name="email" value="<?php echo e($userProfile->email); ?>"></td>
							</tr>
							<tr>
								<td colspan="2">
									<br/>
									<center>
										<a href="<?php echo e(route('user.show',$userProfile->userId)); ?>">Back</a> | 
										<input type="submit" value="Update">
									</center>
								</td>
							</tr>
						</table>
					</form>
					<br/>
					<br/>
					 <?php if(count($errors) > 0): ?>
					    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					       <label style="color:red; "><?php echo e($error); ?></label>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					 <?php endif; ?>
				</center>
			</td>
			<td width="100"></td>
		</tr>
	</table>
</body>
</html>