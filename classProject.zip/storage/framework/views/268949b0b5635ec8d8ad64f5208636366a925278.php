 
 
 <?php $__env->startSection('main-content'); ?>

    <?php if(Session::has('Success')): ?>
        <label style="color:green;"><?php echo e(Session::get('Success')); ?></label>
	<?php endif; ?>
    <h3>User List</h3>
	<form>
		<label>KEYWORD: </label>
		<input type="text">
		<input type="submit" value="Search">
	</form>
	<br/>
	<table border="1">
		<tr>
			<th>FULL NAME</th>
			<th>USERNAME</th>
			<th>TYPE</th>
			<th>OPTION</th>
		</tr>
		<?php if(count($userlist) > 0): ?>
		   <?php $__currentLoopData = $userlist->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><a href="details.html"><?php echo e($user->fullname); ?></a></td>
					<td><?php echo e($user->username); ?></td>
					<td><?php echo e($user->type); ?></td>
					<td><a href="<?php echo e(route('admin.edit',$user->userId)); ?>">Edit</a> | <a href="<?php echo e(route('admin.destroy',$user->userId)); ?>" onclick="if(confirm('Are Your sure want to delete?')){
                        event.preventDefault();
                        document.getElementById('delete-form-<?php echo e($user->userId); ?>').submit();
                      }else{
                        event.preventDefault();
                      }">Delete</a></td>
					<form id="delete-form-<?php echo e($user->userId); ?>" action="<?php echo e(route('admin.destroy',$user->userId)); ?>" style="display: none;" method="post">

						<?php echo e(csrf_field()); ?>


						<?php echo e(method_field('DELETE')); ?>


					</form>

				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>	 
	</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>