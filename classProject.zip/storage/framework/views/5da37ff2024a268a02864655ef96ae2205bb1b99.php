<?php $__env->startSection('main-content'); ?>


   <?php if(Session::has('message')): ?>
	   <span style="color:red"><?php echo e(Session::get('message')); ?></span>
	<?php endif; ?>
	
	<h3>Change Password</h3>
	<form method="post" action="<?php echo e(route('adminSettingUpdate',$userInfo->userId)); ?>">
	  <?php echo e(csrf_field()); ?>

	  <?php echo e(method_field('PUT')); ?>


			<table>
				<tr>
					<td>USERNAME: </td>
					<td><?php echo e($userInfo->username); ?></td>
				</tr>
				<tr>
					<td>OLD PASSWORD: </td>
					<td><input type="password" name="oldPassword"></td>
				</tr>
				<tr>
					<td>NEW PASSWORD: </td>
					<td><input type="password" name="newPassword"></td>
				</tr>
				<tr>
					<td>RE-TYPE PASSWORD: </td>
					<td><input type="password" name="retypePassword"></td>
				</tr>
				<tr>
					<td colspan="2">
						<br/>
						<center>
							<a href="<?php echo e(route('adminHome')); ?>">Back</a> | 
							<input type="submit" value="Update">
						</center>
					</td>
				</tr>
			</table>
		</form>
		<br/>
		<br/>
		 <?php if(count($errors) > 0): ?>
		    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		       <label style="color: red;"><?php echo e($error); ?></label><br>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		 <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>