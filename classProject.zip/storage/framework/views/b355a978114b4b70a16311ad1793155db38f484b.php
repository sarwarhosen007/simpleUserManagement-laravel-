 

 <?php $__env->startSection('main-content'); ?>
 <h3>Edit User Information</h3>
	<form method="post" action="<?php echo e(route('admin.update',$user->userId)); ?>">
	       <?php echo e(csrf_field()); ?>

	       <?php echo e(method_field('PUT')); ?>

			<table>
				<tr>
					<td>FULL NAME: </td>
					<td><?php echo e($profile->fullname); ?></td>
				</tr>
				<tr>
					<td>USERNAME: </td>
					<td><?php echo e($user->username); ?></td>
				</tr>
				<tr>
					<td>TYPE: </td>
					<td>
						<select name="type">
							<option <?php if($user->type == 'Admin'): ?> <?php echo e('selected'); ?> <?php endif; ?> >Admin</option>
							<option <?php if($user->type == 'User'): ?> 
							 <?php echo e('selected'); ?>  <?php endif; ?>>User</option>
						</select>
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<br/>
						<center>
							<a href="<?php echo e(route('admin.index')); ?>">Back</a> | 
							<input type="submit" value="Confirm">
						</center>
					</td>
				</tr>
			</table>
	</form>
	<br/>
	<br/>
	<?php if(Session::has('Error')): ?>
		<label style="color:red;"><?php echo e(Session::get('Error')); ?></label>
	<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>