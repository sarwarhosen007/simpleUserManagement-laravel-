<?php $__env->startSection('main-content'); ?>
  
  <?php if(Session::has('UpdateSuccessMessage')): ?>
		<span style="color: blue;"><?php echo e(Session::get('UpdateSuccessMessage')); ?></span>
	<?php endif; ?>
	<?php if(Session::has('message')): ?>
		<span style="color: blue;"><?php echo e(Session::get('message')); ?></span>
	<?php endif; ?>
		<h3>My Profile</h3>
<form method="post">
	<table>
		<tr>
			<td>FULL NAME: </td>
			<td><?php echo e($userInfoProfile->fullname); ?></td>
		</tr>
		<tr>
			<td>EMAIL: </td>
			<td><?php echo e($userInfoProfile->email); ?></td>
		</tr>
		<tr>
			<td>USERNAME: </td>
			<td><?php echo e($userInfoUser->username); ?></td>
		</tr>
		<tr>
			<td>TYPE: </td>
			<td><?php echo e($userInfoUser->type); ?></td>
		</tr>
		<tr>
			<td colspan="2">
				<br/>
				<center>
					<a href="<?php echo e(route('userHome')); ?>">Back</a> | 
					<a href="<?php echo e(route('user.edit',$userInfoProfile->userId)); ?>">Edit</a>
				</center>
			</td>
		</tr>
	</table>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>