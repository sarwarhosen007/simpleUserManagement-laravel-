 

 <?php $__env->startSection('main-content'); ?>

   <h3>Admin Home</h3>
	<p>Welcome <strong><?php echo e(Session()->get('userFullName')); ?>

	               
	</strong></p>
	<p>Your last login was on <?php echo e(Session()->get('userLastLogin')); ?>

	                PM</p>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>